package com.human.middle.dao;

import com.human.middle.dto.Board;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
@RequiredArgsConstructor
public class BoardDao {
    private final JdbcTemplate jdbcTemplate;

    // 게시글 작성
    public boolean save(Board board) {
        String sql = "INSERT INTO board(title, content, member_id) VALUES (?, ?, ?)";
        int rst = jdbcTemplate.update(sql,
                board.getTitle(), board.getContent(), board.getMemberId());
        return rst > 0;
    }

    // 게시글 전체 목록 조회
    public List<Board> findAll() {
        String sql = "SELECT * FROM board";
    }
    // 게시글 상세 조회 (boardId)
    public Optional<Board> findById(Long id) {

    }
    // 게시글 수정 (boardId, 제목, 내용)

    // 게시글 삭제 (boardId)

    // 조회수 증가
    public boolean increaseViewCount(Long id) {

    }
}
